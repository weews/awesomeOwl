# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 2: Working with integers

# Go to: https://www.onlinegdb.com/online_python_compiler

# Assign integer values to two variables x, y
x = 5
y = 3
# Display the type for variable x
print (type(x))

# Our first computation in Python!
# Can you guess/explain the answer?
print (x + y * 4)

# Exercise: Can you guess/explain the result given by the line of code below.
#           print (20 + 10 * 15 / 5)

# Copyright 2020 Wee Wen Shih. All rights reserved.