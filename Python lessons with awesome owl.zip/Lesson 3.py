# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 3: Working with floating point numbers (decimals)

# Go to: https://www.onlinegdb.com/online_python_compiler

# Assign floating point values to two variables weight, height
weight = 60.2
height = 155/100
# Display the type for variable weight
print (type(weight))

# Calculate body mass index using a given formula
# ** 2 refers to the power of 2 in Python
bmi = weight / (height ** 2) 
# Print the message and the value separated by space
print ("BMI =", bmi, sep = " ")

# Exercise: Write code to calculate the body surface area.

# Copyright 2020 Wee Wen Shih. All rights reserved.