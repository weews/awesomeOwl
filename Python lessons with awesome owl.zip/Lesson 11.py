# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 10: Using strings and lists

# Go to: https://www.onlinegdb.com/online_python_compiler

# We will write code to count vowels and consonants for a given string,
# by means of a function.

def analyseText(s):
    # Initialise the important variables to zero
    numVowels = 0
    numConsonants = 0

    # Loop for the characters in the string s
    for i in s:
        # Check whether i is a member of the list of vowels,
        # increment numVowels, if so
        if i in ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']:
            numVowels += 1
        # Check whether i is a member of the list of punctuations,
        # do nothing, if so
        elif i in [' ', ',', '.', ';', '?']:
            pass
        # Character must be a consonant otherwise, increment numConsonants
        else:
            numConsonants += 1
    
    # Display the results
    print ("Number of vowels:", numVowels)
    print ("Number of consonants:", numConsonants)

# Prompt the user for an input string,
# such as: This is an example, my friend.
inputStr = input("Enter a line of text: ")
# Call the function analyseText
analyseText(inputStr)

# Exercise: Modify the algorithm to count the number of punctuations.

# Copyright 2020 Wee Wen Shih. All rights reserved.