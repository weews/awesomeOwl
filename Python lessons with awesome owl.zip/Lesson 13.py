# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 13: Using recursion

# Go to: https://www.onlinegdb.com/online_python_compiler

# We will call a function repeatedly, via recursion.
# In computer science, recursion is a method of solving a problem
# where the solution depends on solutions to smaller instances
# of the same problem.

# recursiveSum is a recursive function to calculate the value of
# 1 + 2 + 3 + ... + n.
def recursiveSum(n):
    if n == 1: # The base case returns a value without making any subsequent recursive calls
        return 1
    else: # Recursive call to a smaller instance of the same problem
        return n + recursiveSum(n - 1)

# Call the function recursiveSum
print (recursiveSum(10))

# Exercise: Write the function iterativeSum(n) using a loop.

# Copyright 2020 Wee Wen Shih. All rights reserved.