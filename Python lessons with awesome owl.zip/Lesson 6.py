# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 6: Making complex decisions

# Go to: https://www.onlinegdb.com/online_python_compiler

# We present a real-life situation below.

"""
A software company sells a package that retails for $99.
Quantity discounts are applied if the number of packages
order is:

Quantity       Discount
10 - 19        25%
20 - 49        30%
50 or more     35%

Write Python code that:
(1) prompts the user to enter the number of software packages
    ordered,
(2) calculates the cost of the purchase,
(3) displays the result, to the nearest cent.
"""

# Logically, a typical program consists of the input, processing and output steps.

# Input step
# Prompt the user to enter quantity
quantity = int(input("Enter the number ordered: "))

# Processing step
# Use the if-elif-else instruction so as to deal with complex situations.
if (quantity < 10):
    discount = 0
elif (quantity >= 10 and quantity < 20):
    discount = 0.25
elif (quantity >= 20 and quantity < 50):
    discount = 0.3
else:
    discount = 0.35
# Calculate cost, with discount, if any
cost = 99 * quantity * (1 - discount)

# Ouput step
# Use the format instruction to display cost to the nearest cent (2 decimal places)
print ("Cost: $", format(cost, '.2f'), sep = "")

# Exercise: Write code to assign a certain grade to a given mark.

# Copyright 2020 Wee Wen Shih. All rights reserved.