# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 1: Hello

# Go to: https://www.onlinegdb.com/online_python_compiler
# It is an online integrated development environment (IDE) for coding in Python.

# Why learn to code?
# It is what many people are doing so today.
# It is fun, engaging, and you become creative and imaginative!

# Everybody should learn how to program a computer
# because it teaches you how to think.
# Steve Jobs

# Our first line of Python code!
print ("Hello to the world of Python programming")

# In programming, we call message a variable.
# Variable refers to a data storage location within the computer.
# It is a good coding habit to give a meaningful name to any variable.
message = "ni hao ma?"
print (message)

# message takes in a string value.
print (type(message))

# Exercise: Go find out how one could print hello! on each line for 21 times,
#           using a single print statement.

# Copyright 2020 Wee Wen Shih. All rights reserved.

