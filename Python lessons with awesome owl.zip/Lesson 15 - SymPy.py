# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 15: Using SymPy

# Go to: https://pythonbaba.com/online-python-code-editor-and-ide-for-data-science/

# SymPy is a Python library for symbolic mathematics.

# We need this line to use SymPy instructions
import sympy as sym

# Add two fractions
a = sym.Rational(1, 2)
b = sym.Rational(2, 7)
print (a + b)

# Numerically evaluate the square root of 5 to 50 decimal places
c = sym.N(sym.sqrt(5), 51)
print (c)

# Define variables first before manipulating expressions
x, y, z = sym.symbols('x y z')

# Expand an algebraic expression
z = sym.expand((x - 2 * y) ** 3)
print (z)

# Factorise an algebraic expression
z = sym.factor(x ** 3 + 3 * x ** 2 + 3 * x + 1)
print (z)

# Simplify a trigonometric expression
z = sym.simplify(sym.cos(x/2) ** 2 - sym.sin(x/2) ** 2)
print (z)

# Carry out differentiation and display the result
expression = x**3 - x**2
print(sym.diff(expression, x))

# Evaluate derivative at the point (x = 2) and display the result
derivative = sym.lambdify(x, sym.diff(expression, x))
print (derivative(2))

# Carry out integration and display the result
print (sym.integrate(expression, x))

# Evaluate a definite integral (with limits 0, 2) and display the result
result = sym.integrate(expression, (x, 0, 2))
print (result)

# Yet again, we have just coded a mini WolframAlpha, yay!

# Copyright 2020 Wee Wen Shih. All rights reserved.