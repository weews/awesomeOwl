# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 8: Implementing a check-digit algorithm

# Go to: https://www.onlinegdb.com/online_python_compiler

"""
We will write code to check whether a 13-digit book number is valid or not,
based on the following algorithm:
(1) add up the odd-position digits,
(2) multiply each even-position digits by 3 and add them up,
(3) the sum of (1) and (2) must be divisible by 10.
"""

# Initialise sum
sum = 0

# Loop 13 times
for i in range(13):
    j = int(input("Enter digit: ")) # Prompt the user for a digit
    if (i + 1) % 2 == 0: # Digit is in an even position
        sum = sum + (3 * j) # Multiply the digit by 3, add to sum
    else: # Digit is in an odd position
        sum = sum + j # Add the digit to sum

# Display the result
if sum % 10 == 0: # Sum is divisible by 10
    print ("Valid book number")
else:
    print ("Invalid book number")

# Test your algorithm with these book numbers:
# 9781848002906
# 9781848009206

# Exercise: Write code to check the validity of a given International
#           Standard Serial Number.

# Copyright 2020 Wee Wen Shih. All rights reserved.    