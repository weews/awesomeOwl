# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 12: Implementing queues via lists

# Go to: https://www.onlinegdb.com/online_python_compiler

# We will code a program to model the flow of customers through 
# a check-out line (queue) in a store.

# Queue is a data structure that is commonly used in programming.
# Elements are added to the rear and removed from the front - a first-in,
# first-out structure as such.

# Use the random module to generate a random number later
import random

# Create an empty queue, via a list implementation
queue = []

# Initialise customer ID
custID = 1

# Loop for 10 minutes
for time in range(10):
    
    print("During minute", time + 1)

    # Remove a customer at the front
    # Use pop(0) instruction in Python
    if len(queue) != 0:
        queue.pop(0)
        print("Customer removed")
        print("Queue:", queue)

    # Generate k, a random number 0, 1, 2, or 3
    k = random.randint(0, 3)

    # Add one customer, two customers, or none, depending on k's value
    # Use append instruction in Python
    if k == 1:
        queue.append(custID)
        custID += 1
        print("1 customer added")
        print("Queue:", queue)
        
    elif k == 2:
        queue.append(custID)
        custID += 1
        queue.append(custID)
        custID += 1
        print("2 customers added")
        print("Queue:", queue)
        
    else:
        print("No customers added")
        print("Queue:", queue)

# Exercise: Write code that creates a list of 20 random integers and displays 
#           the sum of those integers that are divisible by 5.

# Copyright 2020 Wee Wen Shih. All rights reserved.