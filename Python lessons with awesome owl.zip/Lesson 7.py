# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 7: Implementing algorithms with for-loops

# Go to: https://www.onlinegdb.com/online_python_compiler

# In coding, we implement algorithms.
# An algorithm is a set of mathematical instructions or rules that,
# especially if given to a computer, will help to calculate an answer
# to a problem.

# Suppose we wish to add 10 integers.
# We will implement the algorithm using the input, processing and output steps.

# Initialise sum to zero
sum = 0

# Input and processing steps
# Use the for instruction to obtain an integer and add it to sum 10 times
for i in range(10):
    j = int(input("Enter an integer: "))
    sum = sum + j

# Output step
print ("Sum of 10 integers:", sum)

# Exercise: Write code to print all multiples of 7 that are smaller than 2021.

# Copyright 2020 Wee Wen Shih. All rights reserved.