# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 5: Making simple decisions

# Go to: https://www.onlinegdb.com/online_python_compiler

# Prompt the user for a temperature using the input instruction,
# then convert it to a floating point number
temperature = float(input("Enter a temperature: "))

# We can make our code appear smart by using the
# if-else instruction to make simple decisions.
if (temperature > 37.5):
    print ("You cannot enter the premise.")
else:
    print ("You may enter the premise.")

# Exercise: Write code that takes in two integer values from the user
#           and display the larger of two values.

# Copyright 2020 Wee Wen Shih. All rights reserved.