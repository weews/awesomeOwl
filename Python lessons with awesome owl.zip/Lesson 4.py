# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 4: Working with booleans (variables with true/false values)

# Go to: https://www.onlinegdb.com/online_python_compiler

# Booleans are necessary for decision making.

# Variable a takes the value False since 10 is greater than 4
a = (10 < 4)
print (a)
# Variable b takes the value True
b = (10 > 4)
print (b)
# Variable c has the value True
c = (4 == 4)
print (c)
# Display the type for variable a
print (type(a))

# Exercise: State a possible value of i that will cause the statement
#           below to display True. 
#           What value of i will cause the statement to display False?
#           print (2 ** i > 2021)

# Copyright 2020 Wee Wen Shih. All rights reserved.