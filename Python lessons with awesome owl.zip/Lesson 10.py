# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 10: Using functions to implement algorithms

# Go to: https://www.onlinegdb.com/online_python_compiler

# Programmers write functions because functions:
# - allow the same piece of code to run multiple times, thus promoting reusability;
# - break long programs up into smaller components, thus enhancing clarity;
# - can be shared and used by other programmers, thus increasing productivity.

# We will implement the algorithm to check whether an integer is prime or not.
# isPrime takes in an integer n and returns True if n is prime,
# otherwise it returns False.
def isPrime(n):
    i = 2
    while i <= n ** 0.5:
        if (n % i == 0):
            return False
        i += 1
    return True

# Prompt the user for an integer
number = int(input("Enter an integer: "))
# Call the function isPrime and display the appropriate message
if isPrime(number) == True:
    print (number, "is prime", sep = ' ')
else:
    print (number, "is not prime", sep = ' ')

# Exercise: Explain the algorithm in your own words.

# Copyright 2020 Wee Wen Shih. All rights reserved.