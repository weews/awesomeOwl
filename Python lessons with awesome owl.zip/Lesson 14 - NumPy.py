# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 14: Using NumPy

# Go to: https://pythonbaba.com/online-python-code-editor-and-ide-for-data-science/

# NumPy stands for Numerical Python, which is a Python library used for working
# with arrays.

# We need this line to use NumPy instructions
import numpy as np
 
# Create and initialise two arrays which represent vectors
a = np.array([3, 1, 7])
b = np.array([2, 4, -5])

# Vector addition
output = a + 2* b
print (output)

# Vector subtraction
output = 0.5 * b - a
print (output)
 
# Scalar product
output = np.dot(a, b)
print(output)

# Vector product
output = np.cross(a, b)
print(output)

# It seems that we have just coded a mini WolframAlpha!

# Copyright 2020 Wee Wen Shih. All rights reserved.
