# Awesome Owl Tames Python
# By Wee Wen Shih
# Lesson 8: Implementing algorithms with while-loops

# Go to: https://www.onlinegdb.com/online_python_compiler

# We will implement the algorithm for a guessing game.

# Generate a random number for key such that -10 <= key <= 10,
# using Python's random module
import random
key = random.randint(-10, 10)

# Input, processing and output steps within an infinite while-loop
while True:
    # Prompt the user for an integer value
    guess = int(input("Enter your guess between -10 and 10: "))
    # Use the if-elif-else instruction block for the possible game scenarios
    if guess < key:
        print ("Higher, try again...")
    elif guess > key:
        print ("Lower, try again...")
    else:
        print ("Bingo, good try!")
        break # Use the break instruction to exit the infinite loop

# I hope you have enjoyed playing this game :)

# Exercise: Modify the algorithm if the player is allowed only 4 guesses.

# Copyright 2020 Wee Wen Shih. All rights reserved.